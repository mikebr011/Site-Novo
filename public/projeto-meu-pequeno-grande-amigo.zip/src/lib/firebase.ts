/**
 * Firebase Client SDK Initialization and Firestore Integration
 * Configured for project mpga-site
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDocFromServer,
  setDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  limit,
  Unsubscribe,
} from 'firebase/firestore';
import { getAnalytics, isSupported } from 'firebase/analytics';
import firebaseConfig from '../../firebase-applet-config.json';
import { DonationPledge } from '../types';

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// Initialize Analytics conditionally for browser environment
export let analytics: ReturnType<typeof getAnalytics> | null = null;
if (typeof window !== 'undefined') {
  isSupported()
    .then((supported) => {
      if (supported) {
        analytics = getAnalytics(app);
      }
    })
    .catch((err) => {
      console.warn('Analytics initialization skipped:', err);
    });
}

// Error Handling Specification as required by Firebase skill
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error:', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Test Connection on startup as required by Firebase skill
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.warn('Please check your Firebase configuration or internet connection.');
    }
    return false;
  }
}

// Auto-run connection test
if (typeof window !== 'undefined') {
  testConnection().catch(() => {});
}

/**
 * Real-time subscription to Campaign Pledges with fallback
 */
export function subscribeToPledges(
  onData: (pledges: DonationPledge[]) => void,
  onError?: (err: unknown) => void
): Unsubscribe {
  const pledgesCollection = 'pledges';
  try {
    const q = query(collection(db, pledgesCollection), orderBy('createdAt', 'desc'), limit(100));
    return onSnapshot(
      q,
      (snapshot) => {
        const items: DonationPledge[] = [];
        snapshot.forEach((docSnap) => {
          items.push(docSnap.data() as DonationPledge);
        });
        onData(items);
      },
      (error) => {
        console.warn('Firestore snapshot error (using local cache):', error.message);
        if (onError) onError(error);
        try {
          handleFirestoreError(error, OperationType.GET, pledgesCollection);
        } catch {
          // Gracefully suppress unhandled throw so app continues with localStorage
        }
      }
    );
  } catch (err) {
    console.warn('Could not initialize Firestore listener:', err);
    return () => {};
  }
}

/**
 * Save pledge to Firestore with full error handling
 */
export async function savePledgeToFirebase(pledge: DonationPledge): Promise<boolean> {
  const path = `pledges/${pledge.id}`;
  try {
    await setDoc(doc(db, 'pledges', pledge.id), pledge);
    return true;
  } catch (error) {
    console.error('Failed to save pledge to Firebase:', error);
    try {
      handleFirestoreError(error, OperationType.WRITE, path);
    } catch {
      // Fallback
    }
    return false;
  }
}
