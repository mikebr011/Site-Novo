export type ScreenType = 'inicio' | 'projeto' | 'doador';

export interface Child {
  id: string;
  childName: string;
  age: number;
  gender: 'Menino' | 'Menina' | 'Indiferente';
  guardianName: string;
  guardianPhone: string;
  guardianEmail?: string;
  email?: string;
  neighborhood: string;
  password?: string;
  address?: string;
  toyPreference: string;
  wishDetails: string;
  status: 'aguardando' | 'apadrinhado' | 'entregue';
  protocolNumber: string;
  createdAt: string;
  sponsorName?: string;
  sponsorMessage?: string;
}

export interface DonationPledge {
  id: string;
  donorName: string;
  donorEmail?: string;
  donorPhone: string;
  type: 'brinquedos' | 'financeiro' | 'voluntario';
  toyQuantity?: number;
  toyCondition?: 'Novo' | 'Seminovo em ótimo estado';
  dropPointId?: string;
  dropPointName?: string;
  amount?: number;
  paymentMethod?: 'PIX' | 'Cartão' | 'Boleto';
  volunteerRole?: string;
  volunteerAvailability?: string;
  sponsoredChildId?: string;
  sponsoredChildName?: string;
  receiptNumber?: string;
  cpf?: string;
  message?: string;
  status: 'confirmado' | 'entregue';
  createdAt: string;
}

export interface DropPoint {
  id: string;
  name: string;
  address: string;
  neighborhood: string;
  hours: string;
  contactPhone: string;
  responsiblePerson: string;
  mapsQuery: string;
}

export interface TimelineMilestone {
  year: string;
  title: string;
  description: string;
  stat: string;
  statLabel: string;
}

export interface GalleryPhoto {
  id: string;
  url: string;
  fallbackUrl?: string;
  filename?: string;
  title: string;
  subtitle?: string;
  description?: string;
  category: 'entregas' | 'brinquedos' | 'voluntarios' | 'sorrisos';
  year: string;
}
